﻿namespace WindowsFormsApp1
{
    partial class Main
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
      this.panel_RS485 = new System.Windows.Forms.Panel();
      this.pictureBox1 = new System.Windows.Forms.PictureBox();
      this.panel2 = new System.Windows.Forms.Panel();
      this.button_Connect = new Sunny.UI.UISymbolButton();
      this.uiMarkLabel1 = new Sunny.UI.UIMarkLabel();
      this.comboBox_SerialNumber = new Sunny.UI.UIComboBox();
      this.comboBox_BaudRate = new Sunny.UI.UIComboBox();
      this.uiMarkLabel2 = new Sunny.UI.UIMarkLabel();
      this.comboBox_CheckDigit = new Sunny.UI.UIComboBox();
      this.comboBox_DataBits = new Sunny.UI.UIComboBox();
      this.uiMarkLabel3 = new Sunny.UI.UIMarkLabel();
      this.comboBox_StopBit = new Sunny.UI.UIComboBox();
      this.uiLight6 = new Sunny.UI.UILight();
      this.uiMarkLabel5 = new Sunny.UI.UIMarkLabel();
      this.uiMarkLabel4 = new Sunny.UI.UIMarkLabel();
      this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
      this.Mainpanel = new System.Windows.Forms.Panel();
      this.uiSymbolButton1 = new Sunny.UI.UISymbolButton();
      this.Button6_Download = new Sunny.UI.UISymbolButton();
      this.Button5_DATA_OUTPUT = new Sunny.UI.UISymbolButton();
      this.panel4_RACK3 = new System.Windows.Forms.Panel();
      this.button43 = new System.Windows.Forms.Button();
      this.button42 = new System.Windows.Forms.Button();
      this.button41 = new System.Windows.Forms.Button();
      this.button40 = new System.Windows.Forms.Button();
      this.button39 = new System.Windows.Forms.Button();
      this.button38 = new System.Windows.Forms.Button();
      this.button37 = new System.Windows.Forms.Button();
      this.button36 = new System.Windows.Forms.Button();
      this.button35 = new System.Windows.Forms.Button();
      this.button19 = new System.Windows.Forms.Button();
      this.button20 = new System.Windows.Forms.Button();
      this.button21 = new System.Windows.Forms.Button();
      this.button22 = new System.Windows.Forms.Button();
      this.button23 = new System.Windows.Forms.Button();
      this.button24 = new System.Windows.Forms.Button();
      this.button25 = new System.Windows.Forms.Button();
      this.button26 = new System.Windows.Forms.Button();
      this.Button4_RACK3 = new Sunny.UI.UISymbolButton();
      this.panel3_RACK2 = new System.Windows.Forms.Panel();
      this.button34 = new System.Windows.Forms.Button();
      this.button33 = new System.Windows.Forms.Button();
      this.button32 = new System.Windows.Forms.Button();
      this.button31 = new System.Windows.Forms.Button();
      this.button30 = new System.Windows.Forms.Button();
      this.button29 = new System.Windows.Forms.Button();
      this.button28 = new System.Windows.Forms.Button();
      this.button10 = new System.Windows.Forms.Button();
      this.button11 = new System.Windows.Forms.Button();
      this.button12 = new System.Windows.Forms.Button();
      this.button13 = new System.Windows.Forms.Button();
      this.button14 = new System.Windows.Forms.Button();
      this.button15 = new System.Windows.Forms.Button();
      this.button16 = new System.Windows.Forms.Button();
      this.button17 = new System.Windows.Forms.Button();
      this.uiSymbolButton2_RACK2 = new Sunny.UI.UISymbolButton();
      this.panel2_RACK1 = new System.Windows.Forms.Panel();
      this.button1 = new System.Windows.Forms.Button();
      this.button2 = new System.Windows.Forms.Button();
      this.button3 = new System.Windows.Forms.Button();
      this.button4 = new System.Windows.Forms.Button();
      this.button5 = new System.Windows.Forms.Button();
      this.button6 = new System.Windows.Forms.Button();
      this.button7 = new System.Windows.Forms.Button();
      this.button8 = new System.Windows.Forms.Button();
      this.button_RACK1 = new Sunny.UI.UISymbolButton();
      this.Panel_ChildSerialPort = new System.Windows.Forms.Panel();
      this.button_RS485 = new System.Windows.Forms.Button();
      this.Butten_SerialPort = new Sunny.UI.UISymbolButton();
      this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
      this.panel_main = new Sunny.UI.UITitlePanel();
      this.panel3 = new System.Windows.Forms.Panel();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.panel1 = new System.Windows.Forms.Panel();
      this.panel_RS485.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
      this.panel2.SuspendLayout();
      this.Mainpanel.SuspendLayout();
      this.panel4_RACK3.SuspendLayout();
      this.panel3_RACK2.SuspendLayout();
      this.panel2_RACK1.SuspendLayout();
      this.Panel_ChildSerialPort.SuspendLayout();
      this.panel_main.SuspendLayout();
      this.panel1.SuspendLayout();
      this.SuspendLayout();
      // 
      // panel_RS485
      // 
      this.panel_RS485.BackColor = System.Drawing.SystemColors.Control;
      this.panel_RS485.Controls.Add(this.pictureBox1);
      this.panel_RS485.Controls.Add(this.panel2);
      resources.ApplyResources(this.panel_RS485, "panel_RS485");
      this.panel_RS485.Name = "panel_RS485";
      // 
      // pictureBox1
      // 
      resources.ApplyResources(this.pictureBox1, "pictureBox1");
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.TabStop = false;
      // 
      // panel2
      // 
      resources.ApplyResources(this.panel2, "panel2");
      this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.panel2.Controls.Add(this.button_Connect);
      this.panel2.Controls.Add(this.uiMarkLabel1);
      this.panel2.Controls.Add(this.comboBox_SerialNumber);
      this.panel2.Controls.Add(this.comboBox_BaudRate);
      this.panel2.Controls.Add(this.uiMarkLabel2);
      this.panel2.Controls.Add(this.comboBox_CheckDigit);
      this.panel2.Controls.Add(this.comboBox_DataBits);
      this.panel2.Controls.Add(this.uiMarkLabel3);
      this.panel2.Controls.Add(this.comboBox_StopBit);
      this.panel2.Controls.Add(this.uiLight6);
      this.panel2.Controls.Add(this.uiMarkLabel5);
      this.panel2.Controls.Add(this.uiMarkLabel4);
      this.panel2.Name = "panel2";
      // 
      // button_Connect
      // 
      this.button_Connect.Cursor = System.Windows.Forms.Cursors.Hand;
      this.button_Connect.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      resources.ApplyResources(this.button_Connect, "button_Connect");
      this.button_Connect.Name = "button_Connect";
      this.button_Connect.Style = Sunny.UI.UIStyle.Custom;
      this.button_Connect.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.button_Connect.Click += new System.EventHandler(this.button_Connect_Click_1);
      // 
      // uiMarkLabel1
      // 
      resources.ApplyResources(this.uiMarkLabel1, "uiMarkLabel1");
      this.uiMarkLabel1.MarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.uiMarkLabel1.Name = "uiMarkLabel1";
      this.uiMarkLabel1.Click += new System.EventHandler(this.uiMarkLabel1_Click);
      // 
      // comboBox_SerialNumber
      // 
      this.comboBox_SerialNumber.DataSource = null;
      this.comboBox_SerialNumber.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
      this.comboBox_SerialNumber.FillColor = System.Drawing.Color.White;
      resources.ApplyResources(this.comboBox_SerialNumber, "comboBox_SerialNumber");
      this.comboBox_SerialNumber.ItemSelectBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.comboBox_SerialNumber.Name = "comboBox_SerialNumber";
      this.comboBox_SerialNumber.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.comboBox_SerialNumber.Style = Sunny.UI.UIStyle.Custom;
      this.comboBox_SerialNumber.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // comboBox_BaudRate
      // 
      this.comboBox_BaudRate.DataSource = null;
      this.comboBox_BaudRate.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
      this.comboBox_BaudRate.FillColor = System.Drawing.Color.White;
      resources.ApplyResources(this.comboBox_BaudRate, "comboBox_BaudRate");
      this.comboBox_BaudRate.ItemSelectBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.comboBox_BaudRate.Name = "comboBox_BaudRate";
      this.comboBox_BaudRate.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.comboBox_BaudRate.Style = Sunny.UI.UIStyle.Custom;
      this.comboBox_BaudRate.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // uiMarkLabel2
      // 
      resources.ApplyResources(this.uiMarkLabel2, "uiMarkLabel2");
      this.uiMarkLabel2.MarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.uiMarkLabel2.Name = "uiMarkLabel2";
      this.uiMarkLabel2.Click += new System.EventHandler(this.uiMarkLabel2_Click);
      // 
      // comboBox_CheckDigit
      // 
      this.comboBox_CheckDigit.DataSource = null;
      this.comboBox_CheckDigit.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
      this.comboBox_CheckDigit.FillColor = System.Drawing.Color.White;
      resources.ApplyResources(this.comboBox_CheckDigit, "comboBox_CheckDigit");
      this.comboBox_CheckDigit.ItemSelectBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.comboBox_CheckDigit.Name = "comboBox_CheckDigit";
      this.comboBox_CheckDigit.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.comboBox_CheckDigit.Style = Sunny.UI.UIStyle.Custom;
      this.comboBox_CheckDigit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // comboBox_DataBits
      // 
      this.comboBox_DataBits.DataSource = null;
      this.comboBox_DataBits.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
      this.comboBox_DataBits.FillColor = System.Drawing.Color.White;
      resources.ApplyResources(this.comboBox_DataBits, "comboBox_DataBits");
      this.comboBox_DataBits.ItemSelectBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.comboBox_DataBits.Name = "comboBox_DataBits";
      this.comboBox_DataBits.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.comboBox_DataBits.Style = Sunny.UI.UIStyle.Custom;
      this.comboBox_DataBits.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // uiMarkLabel3
      // 
      resources.ApplyResources(this.uiMarkLabel3, "uiMarkLabel3");
      this.uiMarkLabel3.MarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.uiMarkLabel3.Name = "uiMarkLabel3";
      // 
      // comboBox_StopBit
      // 
      this.comboBox_StopBit.DataSource = null;
      this.comboBox_StopBit.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
      this.comboBox_StopBit.FillColor = System.Drawing.Color.White;
      resources.ApplyResources(this.comboBox_StopBit, "comboBox_StopBit");
      this.comboBox_StopBit.ItemSelectBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.comboBox_StopBit.Name = "comboBox_StopBit";
      this.comboBox_StopBit.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.comboBox_StopBit.Style = Sunny.UI.UIStyle.Custom;
      this.comboBox_StopBit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // uiLight6
      // 
      this.uiLight6.CenterColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(248)))), ((int)(((byte)(232)))));
      resources.ApplyResources(this.uiLight6, "uiLight6");
      this.uiLight6.Name = "uiLight6";
      this.uiLight6.OffCenterColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(248)))), ((int)(((byte)(232)))));
      this.uiLight6.OnCenterColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(248)))), ((int)(((byte)(232)))));
      this.uiLight6.Radius = 21;
      this.uiLight6.State = Sunny.UI.UILightState.Blink;
      this.uiLight6.Style = Sunny.UI.UIStyle.Custom;
      // 
      // uiMarkLabel5
      // 
      resources.ApplyResources(this.uiMarkLabel5, "uiMarkLabel5");
      this.uiMarkLabel5.MarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.uiMarkLabel5.Name = "uiMarkLabel5";
      this.uiMarkLabel5.Style = Sunny.UI.UIStyle.Custom;
      // 
      // uiMarkLabel4
      // 
      resources.ApplyResources(this.uiMarkLabel4, "uiMarkLabel4");
      this.uiMarkLabel4.MarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.uiMarkLabel4.Name = "uiMarkLabel4";
      this.uiMarkLabel4.Style = Sunny.UI.UIStyle.Custom;
      // 
      // serialPort1
      // 
      this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.SerialPort1_DataRecive);
      // 
      // Mainpanel
      // 
      this.Mainpanel.AllowDrop = true;
      resources.ApplyResources(this.Mainpanel, "Mainpanel");
      this.Mainpanel.Controls.Add(this.uiSymbolButton1);
      this.Mainpanel.Controls.Add(this.Button6_Download);
      this.Mainpanel.Controls.Add(this.Button5_DATA_OUTPUT);
      this.Mainpanel.Controls.Add(this.panel4_RACK3);
      this.Mainpanel.Controls.Add(this.Button4_RACK3);
      this.Mainpanel.Controls.Add(this.panel3_RACK2);
      this.Mainpanel.Controls.Add(this.uiSymbolButton2_RACK2);
      this.Mainpanel.Controls.Add(this.panel2_RACK1);
      this.Mainpanel.Controls.Add(this.button_RACK1);
      this.Mainpanel.Controls.Add(this.Panel_ChildSerialPort);
      this.Mainpanel.Controls.Add(this.Butten_SerialPort);
      this.Mainpanel.Name = "Mainpanel";
      // 
      // uiSymbolButton1
      // 
      this.uiSymbolButton1.Cursor = System.Windows.Forms.Cursors.Hand;
      resources.ApplyResources(this.uiSymbolButton1, "uiSymbolButton1");
      this.uiSymbolButton1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.uiSymbolButton1.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.uiSymbolButton1.Name = "uiSymbolButton1";
      this.uiSymbolButton1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.uiSymbolButton1.Style = Sunny.UI.UIStyle.Custom;
      this.uiSymbolButton1.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.uiSymbolButton1.Click += new System.EventHandler(this.uiSymbolButton1_Click);
      // 
      // Button6_Download
      // 
      this.Button6_Download.Cursor = System.Windows.Forms.Cursors.Hand;
      resources.ApplyResources(this.Button6_Download, "Button6_Download");
      this.Button6_Download.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.Button6_Download.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.Button6_Download.Name = "Button6_Download";
      this.Button6_Download.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.Button6_Download.Style = Sunny.UI.UIStyle.Custom;
      this.Button6_Download.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.Button6_Download.Click += new System.EventHandler(this.Button6_Download_Click);
      // 
      // Button5_DATA_OUTPUT
      // 
      this.Button5_DATA_OUTPUT.Cursor = System.Windows.Forms.Cursors.Hand;
      resources.ApplyResources(this.Button5_DATA_OUTPUT, "Button5_DATA_OUTPUT");
      this.Button5_DATA_OUTPUT.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.Button5_DATA_OUTPUT.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.Button5_DATA_OUTPUT.Name = "Button5_DATA_OUTPUT";
      this.Button5_DATA_OUTPUT.Style = Sunny.UI.UIStyle.Custom;
      this.Button5_DATA_OUTPUT.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.Button5_DATA_OUTPUT.Click += new System.EventHandler(this.Button5_DATA_OUTPUT_Click);
      // 
      // panel4_RACK3
      // 
      this.panel4_RACK3.Controls.Add(this.button43);
      this.panel4_RACK3.Controls.Add(this.button42);
      this.panel4_RACK3.Controls.Add(this.button41);
      this.panel4_RACK3.Controls.Add(this.button40);
      this.panel4_RACK3.Controls.Add(this.button39);
      this.panel4_RACK3.Controls.Add(this.button38);
      this.panel4_RACK3.Controls.Add(this.button37);
      this.panel4_RACK3.Controls.Add(this.button36);
      this.panel4_RACK3.Controls.Add(this.button35);
      this.panel4_RACK3.Controls.Add(this.button19);
      this.panel4_RACK3.Controls.Add(this.button20);
      this.panel4_RACK3.Controls.Add(this.button21);
      this.panel4_RACK3.Controls.Add(this.button22);
      this.panel4_RACK3.Controls.Add(this.button23);
      this.panel4_RACK3.Controls.Add(this.button24);
      this.panel4_RACK3.Controls.Add(this.button25);
      this.panel4_RACK3.Controls.Add(this.button26);
      resources.ApplyResources(this.panel4_RACK3, "panel4_RACK3");
      this.panel4_RACK3.Name = "panel4_RACK3";
      // 
      // button43
      // 
      resources.ApplyResources(this.button43, "button43");
      this.button43.Name = "button43";
      this.button43.UseVisualStyleBackColor = true;
      // 
      // button42
      // 
      resources.ApplyResources(this.button42, "button42");
      this.button42.Name = "button42";
      this.button42.UseVisualStyleBackColor = true;
      // 
      // button41
      // 
      resources.ApplyResources(this.button41, "button41");
      this.button41.Name = "button41";
      this.button41.UseVisualStyleBackColor = true;
      // 
      // button40
      // 
      resources.ApplyResources(this.button40, "button40");
      this.button40.Name = "button40";
      this.button40.UseVisualStyleBackColor = true;
      // 
      // button39
      // 
      resources.ApplyResources(this.button39, "button39");
      this.button39.Name = "button39";
      this.button39.UseVisualStyleBackColor = true;
      // 
      // button38
      // 
      resources.ApplyResources(this.button38, "button38");
      this.button38.Name = "button38";
      this.button38.UseVisualStyleBackColor = true;
      // 
      // button37
      // 
      resources.ApplyResources(this.button37, "button37");
      this.button37.Name = "button37";
      this.button37.UseVisualStyleBackColor = true;
      // 
      // button36
      // 
      resources.ApplyResources(this.button36, "button36");
      this.button36.Name = "button36";
      this.button36.UseVisualStyleBackColor = true;
      // 
      // button35
      // 
      resources.ApplyResources(this.button35, "button35");
      this.button35.Name = "button35";
      this.button35.UseVisualStyleBackColor = true;
      // 
      // button19
      // 
      resources.ApplyResources(this.button19, "button19");
      this.button19.Name = "button19";
      this.button19.UseVisualStyleBackColor = true;
      // 
      // button20
      // 
      resources.ApplyResources(this.button20, "button20");
      this.button20.Name = "button20";
      this.button20.UseVisualStyleBackColor = true;
      // 
      // button21
      // 
      resources.ApplyResources(this.button21, "button21");
      this.button21.Name = "button21";
      this.button21.UseVisualStyleBackColor = true;
      // 
      // button22
      // 
      resources.ApplyResources(this.button22, "button22");
      this.button22.Name = "button22";
      this.button22.UseVisualStyleBackColor = true;
      // 
      // button23
      // 
      resources.ApplyResources(this.button23, "button23");
      this.button23.Name = "button23";
      this.button23.UseVisualStyleBackColor = true;
      // 
      // button24
      // 
      resources.ApplyResources(this.button24, "button24");
      this.button24.Name = "button24";
      this.button24.UseVisualStyleBackColor = true;
      // 
      // button25
      // 
      resources.ApplyResources(this.button25, "button25");
      this.button25.Name = "button25";
      this.button25.UseVisualStyleBackColor = true;
      // 
      // button26
      // 
      resources.ApplyResources(this.button26, "button26");
      this.button26.Name = "button26";
      this.button26.UseVisualStyleBackColor = true;
      // 
      // Button4_RACK3
      // 
      this.Button4_RACK3.Cursor = System.Windows.Forms.Cursors.Hand;
      resources.ApplyResources(this.Button4_RACK3, "Button4_RACK3");
      this.Button4_RACK3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.Button4_RACK3.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.Button4_RACK3.Name = "Button4_RACK3";
      this.Button4_RACK3.Style = Sunny.UI.UIStyle.Custom;
      this.Button4_RACK3.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.Button4_RACK3.Click += new System.EventHandler(this.Button4_RACK3_Click);
      // 
      // panel3_RACK2
      // 
      this.panel3_RACK2.Controls.Add(this.button34);
      this.panel3_RACK2.Controls.Add(this.button33);
      this.panel3_RACK2.Controls.Add(this.button32);
      this.panel3_RACK2.Controls.Add(this.button31);
      this.panel3_RACK2.Controls.Add(this.button30);
      this.panel3_RACK2.Controls.Add(this.button29);
      this.panel3_RACK2.Controls.Add(this.button28);
      this.panel3_RACK2.Controls.Add(this.button10);
      this.panel3_RACK2.Controls.Add(this.button11);
      this.panel3_RACK2.Controls.Add(this.button12);
      this.panel3_RACK2.Controls.Add(this.button13);
      this.panel3_RACK2.Controls.Add(this.button14);
      this.panel3_RACK2.Controls.Add(this.button15);
      this.panel3_RACK2.Controls.Add(this.button16);
      this.panel3_RACK2.Controls.Add(this.button17);
      resources.ApplyResources(this.panel3_RACK2, "panel3_RACK2");
      this.panel3_RACK2.Name = "panel3_RACK2";
      // 
      // button34
      // 
      resources.ApplyResources(this.button34, "button34");
      this.button34.Name = "button34";
      this.button34.UseVisualStyleBackColor = true;
      // 
      // button33
      // 
      resources.ApplyResources(this.button33, "button33");
      this.button33.Name = "button33";
      this.button33.UseVisualStyleBackColor = true;
      // 
      // button32
      // 
      resources.ApplyResources(this.button32, "button32");
      this.button32.Name = "button32";
      this.button32.UseVisualStyleBackColor = true;
      // 
      // button31
      // 
      resources.ApplyResources(this.button31, "button31");
      this.button31.Name = "button31";
      this.button31.UseVisualStyleBackColor = true;
      // 
      // button30
      // 
      resources.ApplyResources(this.button30, "button30");
      this.button30.Name = "button30";
      this.button30.UseVisualStyleBackColor = true;
      // 
      // button29
      // 
      resources.ApplyResources(this.button29, "button29");
      this.button29.Name = "button29";
      this.button29.UseVisualStyleBackColor = true;
      // 
      // button28
      // 
      resources.ApplyResources(this.button28, "button28");
      this.button28.Name = "button28";
      this.button28.UseVisualStyleBackColor = true;
      // 
      // button10
      // 
      resources.ApplyResources(this.button10, "button10");
      this.button10.Name = "button10";
      this.button10.UseVisualStyleBackColor = true;
      // 
      // button11
      // 
      resources.ApplyResources(this.button11, "button11");
      this.button11.Name = "button11";
      this.button11.UseVisualStyleBackColor = true;
      // 
      // button12
      // 
      resources.ApplyResources(this.button12, "button12");
      this.button12.Name = "button12";
      this.button12.UseVisualStyleBackColor = true;
      // 
      // button13
      // 
      resources.ApplyResources(this.button13, "button13");
      this.button13.Name = "button13";
      this.button13.UseVisualStyleBackColor = true;
      // 
      // button14
      // 
      resources.ApplyResources(this.button14, "button14");
      this.button14.Name = "button14";
      this.button14.UseVisualStyleBackColor = true;
      // 
      // button15
      // 
      resources.ApplyResources(this.button15, "button15");
      this.button15.Name = "button15";
      this.button15.UseVisualStyleBackColor = true;
      // 
      // button16
      // 
      resources.ApplyResources(this.button16, "button16");
      this.button16.Name = "button16";
      this.button16.UseVisualStyleBackColor = true;
      // 
      // button17
      // 
      resources.ApplyResources(this.button17, "button17");
      this.button17.Name = "button17";
      this.button17.UseVisualStyleBackColor = true;
      // 
      // uiSymbolButton2_RACK2
      // 
      this.uiSymbolButton2_RACK2.Cursor = System.Windows.Forms.Cursors.Hand;
      resources.ApplyResources(this.uiSymbolButton2_RACK2, "uiSymbolButton2_RACK2");
      this.uiSymbolButton2_RACK2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.uiSymbolButton2_RACK2.Name = "uiSymbolButton2_RACK2";
      this.uiSymbolButton2_RACK2.Style = Sunny.UI.UIStyle.Custom;
      this.uiSymbolButton2_RACK2.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.uiSymbolButton2_RACK2.Click += new System.EventHandler(this.uiSymbolButton2_RACK2_Click);
      // 
      // panel2_RACK1
      // 
      this.panel2_RACK1.Controls.Add(this.button1);
      this.panel2_RACK1.Controls.Add(this.button2);
      this.panel2_RACK1.Controls.Add(this.button3);
      this.panel2_RACK1.Controls.Add(this.button4);
      this.panel2_RACK1.Controls.Add(this.button5);
      this.panel2_RACK1.Controls.Add(this.button6);
      this.panel2_RACK1.Controls.Add(this.button7);
      this.panel2_RACK1.Controls.Add(this.button8);
      resources.ApplyResources(this.panel2_RACK1, "panel2_RACK1");
      this.panel2_RACK1.Name = "panel2_RACK1";
      // 
      // button1
      // 
      resources.ApplyResources(this.button1, "button1");
      this.button1.Name = "button1";
      this.button1.UseVisualStyleBackColor = true;
      // 
      // button2
      // 
      resources.ApplyResources(this.button2, "button2");
      this.button2.Name = "button2";
      this.button2.UseVisualStyleBackColor = true;
      // 
      // button3
      // 
      resources.ApplyResources(this.button3, "button3");
      this.button3.Name = "button3";
      this.button3.UseVisualStyleBackColor = true;
      // 
      // button4
      // 
      resources.ApplyResources(this.button4, "button4");
      this.button4.Name = "button4";
      this.button4.UseVisualStyleBackColor = true;
      // 
      // button5
      // 
      resources.ApplyResources(this.button5, "button5");
      this.button5.Name = "button5";
      this.button5.UseVisualStyleBackColor = true;
      // 
      // button6
      // 
      resources.ApplyResources(this.button6, "button6");
      this.button6.Name = "button6";
      this.button6.UseVisualStyleBackColor = true;
      this.button6.Click += new System.EventHandler(this.button6_Click);
      // 
      // button7
      // 
      resources.ApplyResources(this.button7, "button7");
      this.button7.Name = "button7";
      this.button7.UseVisualStyleBackColor = true;
      this.button7.Click += new System.EventHandler(this.button7_Click);
      // 
      // button8
      // 
      resources.ApplyResources(this.button8, "button8");
      this.button8.Name = "button8";
      this.button8.UseVisualStyleBackColor = true;
      this.button8.Click += new System.EventHandler(this.button8_Click);
      // 
      // button_RACK1
      // 
      this.button_RACK1.Cursor = System.Windows.Forms.Cursors.Hand;
      resources.ApplyResources(this.button_RACK1, "button_RACK1");
      this.button_RACK1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.button_RACK1.Name = "button_RACK1";
      this.button_RACK1.Style = Sunny.UI.UIStyle.Custom;
      this.button_RACK1.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.button_RACK1.Click += new System.EventHandler(this.button_RACK1_Click);
      // 
      // Panel_ChildSerialPort
      // 
      this.Panel_ChildSerialPort.Controls.Add(this.button_RS485);
      resources.ApplyResources(this.Panel_ChildSerialPort, "Panel_ChildSerialPort");
      this.Panel_ChildSerialPort.Name = "Panel_ChildSerialPort";
      // 
      // button_RS485
      // 
      resources.ApplyResources(this.button_RS485, "button_RS485");
      this.button_RS485.Name = "button_RS485";
      this.button_RS485.UseVisualStyleBackColor = true;
      // 
      // Butten_SerialPort
      // 
      this.Butten_SerialPort.Cursor = System.Windows.Forms.Cursors.Hand;
      resources.ApplyResources(this.Butten_SerialPort, "Butten_SerialPort");
      this.Butten_SerialPort.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.Butten_SerialPort.Name = "Butten_SerialPort";
      this.Butten_SerialPort.Style = Sunny.UI.UIStyle.Custom;
      this.Butten_SerialPort.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.Butten_SerialPort.Click += new System.EventHandler(this.Butten_SerialPort_Click_1);
      // 
      // openFileDialog1
      // 
      this.openFileDialog1.FileName = "openFileDialog1";
      // 
      // panel_main
      // 
      resources.ApplyResources(this.panel_main, "panel_main");
      this.panel_main.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
      this.panel_main.Controls.Add(this.panel3);
      this.panel_main.Name = "panel_main";
      this.panel_main.Radius = 1;
      this.panel_main.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
      this.panel_main.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      this.panel_main.Style = Sunny.UI.UIStyle.Custom;
      this.panel_main.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
      this.panel_main.TitleColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(170)))), ((int)(((byte)(50)))));
      // 
      // panel3
      // 
      resources.ApplyResources(this.panel3, "panel3");
      this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.panel3.Name = "panel3";
      // 
      // textBox1
      // 
      this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
      resources.ApplyResources(this.textBox1, "textBox1");
      this.textBox1.Name = "textBox1";
      // 
      // panel1
      // 
      this.panel1.Controls.Add(this.textBox1);
      resources.ApplyResources(this.panel1, "panel1");
      this.panel1.Name = "panel1";
      // 
      // Main
      // 
      this.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
      resources.ApplyResources(this, "$this");
      this.Controls.Add(this.panel_main);
      this.Controls.Add(this.panel1);
      this.Controls.Add(this.Mainpanel);
      this.Controls.Add(this.panel_RS485);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
      this.Name = "Main";
      this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
      this.panel_RS485.ResumeLayout(false);
      this.panel_RS485.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
      this.panel2.ResumeLayout(false);
      this.panel2.PerformLayout();
      this.Mainpanel.ResumeLayout(false);
      this.panel4_RACK3.ResumeLayout(false);
      this.panel3_RACK2.ResumeLayout(false);
      this.panel2_RACK1.ResumeLayout(false);
      this.Panel_ChildSerialPort.ResumeLayout(false);
      this.panel_main.ResumeLayout(false);
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel_RS485;
        internal System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Panel Mainpanel;
        private System.Windows.Forms.Panel Panel_ChildSerialPort;
        private System.Windows.Forms.Button button_RS485;
        public System.Windows.Forms.OpenFileDialog openFileDialog1;
        private Sunny.UI.UISymbolButton Butten_SerialPort;
        private Sunny.UI.UIMarkLabel uiMarkLabel5;
        private Sunny.UI.UIMarkLabel uiMarkLabel4;
        private Sunny.UI.UIMarkLabel uiMarkLabel3;
        private Sunny.UI.UIMarkLabel uiMarkLabel2;
        private Sunny.UI.UIMarkLabel uiMarkLabel1;
        private Sunny.UI.UIComboBox comboBox_StopBit;
        private Sunny.UI.UIComboBox comboBox_DataBits;
        private Sunny.UI.UIComboBox comboBox_CheckDigit;
        private Sunny.UI.UIComboBox comboBox_BaudRate;
        private Sunny.UI.UIComboBox comboBox_SerialNumber;
        private Sunny.UI.UISymbolButton button_RACK1;
        private Sunny.UI.UISymbolButton Button6_Download;
        private Sunny.UI.UISymbolButton Button5_DATA_OUTPUT;
        private Sunny.UI.UISymbolButton Button4_RACK3;
        private Sunny.UI.UISymbolButton uiSymbolButton2_RACK2;
        private Sunny.UI.UILight uiLight6;
        private Sunny.UI.UITitlePanel panel_main;
        private System.Windows.Forms.Panel panel4_RACK3;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Panel panel3_RACK2;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Panel panel2_RACK1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Sunny.UI.UISymbolButton button_Connect;
        private System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.Button button8;
        public System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel1;
        private Sunny.UI.UISymbolButton uiSymbolButton1;
    public System.Windows.Forms.Panel panel3;
  }
}

